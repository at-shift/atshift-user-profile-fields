=== atshift User Profile Fields ===
Contributors: atshift
Tags: user profile, profile fields, custom fields, users, admin
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 1.0.0.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Add custom user profile fields and hide unnecessary default WordPress profile fields.

== Description ==

atshift User Profile Fields helps administrators create cleaner WordPress user profile screens.

The basic version includes:

* Custom profile fields
* Required field validation
* Select, radio, checkbox, text, textarea, email, URL, and number fields
* Default WordPress profile field visibility controls
* Downloadable JSON distribution sets and validated file import
* Bundled WordPress default profile preset for user creation and saved-user editing
* Protected deletion of plugin settings and optional custom profile values
* A designed admin interface for everyday profile management

== Links ==

* Official website: [upf.at-shift.net/en](https://upf.at-shift.net/en/)
* Pro add-on: [Upgrade to Pro](https://upf.at-shift.net/en/pro/)

== Pro Add-on ==

The optional Pro add-on extends the field sets created with the free plugin. It is installed alongside this free base plugin.

Pro adds user classifications, visibility and editing permissions, public profiles, user directories, shortcodes, and CSV workflows for sites that need to publish or manage profile data beyond the WordPress admin screens.

== Displaying Custom Field Values ==

Custom fields are saved as user meta. Use the field key shown in the field editor.

The recommended helper returns the raw saved value, so escape it for the output context:

`
$value = atshift_upf_get_user_field( 'your_field_key', $user_id );
echo esc_html( $value );
`

You can also read the user meta directly. The meta key is `_atshift_upf_` followed by the saved field key:

`
$value = get_user_meta( $user_id, '_atshift_upf_your_field_key', true );
echo esc_html( $value );
`

Text, textarea, email, URL, number, select, and radio fields save a single sanitized value. Image fields save the selected image URL, so escape them as URLs:

`
$image_url = atshift_upf_get_user_field( 'profile_image', $user_id );
if ( $image_url ) {
	echo '<img src="' . esc_url( $image_url ) . '" alt="">';
}
`

Checkbox fields save `1` when checked and `0` when unchecked. Standard WordPress profile fields, such as email, first name, and website, use the normal WordPress user APIs instead of the `_atshift_upf_` custom meta key.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin from the Plugins screen.
3. Open Settings > atshift User Profile Fields.

== Screenshots ==

1. Field Management screen with draggable grouped profile fields and WordPress default profile fields.
2. New field editor with custom field types, groups, and default WordPress profile fields.
3. Add User screen rendered from a saved field set with required badges and grouped controls.
4. Display Settings screen for hiding unused default WordPress profile items.

== Related Projects ==

* [atshift Freeform Login beta](https://upf.at-shift.net/en/freeform-login/) - design the WordPress login screen and place a matching login form on site pages.
* [at-shift Fields](https://wordpress.org/plugins/atshift-fields-maintenance-for-custom-field-suite/) - arrange custom fields for posts and custom post types with a similar field-building experience.

== Changelog ==

= 1.0.0.3 =
* Keep field editor tooltips visible within the field panel and narrow screens.

= 1.0.0.2 =
* Sanitize submitted field-editor and profile values before extension hooks receive them.
* Keep WordPress.org review packages free of development-only markdown files.

= 0.9.3 =
* Integrate the planned 1.0 compatibility updates into the public beta.
* Restrict the Role field to roles the current user is allowed to assign, including compatible custom roles.
* Preserve registered add-on field types and settings when saving the field editor.
* Hide add-on field types from profile screens while their registering add-on is inactive.
* Add live language previews, WordPress role terminology, plugin details links, and add-on cleanup support.

= 0.9.2 =
* Update live language previews for managed profile labels, controls, notes, and WordPress account sections.

= 0.9.1 =
* Use the official WordPress Japanese term for user roles throughout the default profile field and translations.

= 0.9 =
* Add the base integration layer used by optional add-ons.
* Organize Fields and Display Settings as plugin submenus.
* Improve required labels, array-value validation, profile layouts, tooltips, and cache-safe asset loading.
* Allow add-ons to extend field types, profile rendering, field settings, tools tabs, and field ordering.

= 0.2.0 =
* Prevent saved read-only usernames from being treated as empty during required-field validation.

= 0.1.112 =
* Show Fields-style required-field summaries, inline errors, highlighting, and accordion error markers on profile screens.
* Skip validation and saving for inactive conditional branches.

= 0.1.111 =
* Restore the live Admin Color Scheme preview while editing any user and keep the saved scheme visible after reload.
* Allow the bundled default profile presets to import the Visual Editor field.

= 0.1.110 =
* Add base-plugin extension points for future Pro add-ons.
* Allow add-ons to extend field settings, profile screen availability, field-set import/export, and plugin data cleanup.
* Clarify Extras behavior and allow checkbox-driven profile features to be turned off while hidden.
* Add initial-state toggles for checkbox-driven standard fields when new accounts are created.

= 0.1.109 =
* Apply field role controls to the user editing the profile instead of the user being edited.
* Keep administrator-only profile controls visible when an administrator edits users with other roles.

= 0.1.108 =
* Show @shift as the plugin author.
* Add WordPress update notifications and standard automatic-update support for packaged GitHub releases.

= 0.1.107 =
* Select the site default language when the Add New User screen first opens.
* Preserve an explicitly selected language when the form is shown again after validation.

= 0.1.106 =
* Add an Extras integration for hiding the profile section added by User Role Editor.
* Prevent the native WordPress capabilities section from returning when that integration is hidden.

= 0.1.105 =
* Keep role-restricted core feature fields hidden instead of restoring their native WordPress rows.
* Preserve a single feature panel when role control hides an item between visible feature fields.

= 0.1.104 =
* Add a helper and documentation for displaying saved custom profile field values.

= 0.1.103 =
* Preview bundled default profile field labels and notes immediately when the profile language selector changes.
* Keep bundled default profile labels and notes aligned with the current site or user display language.
* Refine Japanese bundled profile text to match the atshift Fields writing style.
* Require server-side confirmation before the tools screen deletes plugin data.

= 0.1.100 =
* Use a plain-language label for the bundled public display-name field.

= 0.1.99 =
* Clarify the bundled display-name field label as a name display format setting.

= 0.1.98 =
* Keep Nickname visually optional in bundled defaults and validate only attempts to save it blank.

= 0.1.97 =
* Place Username outside and immediately before the Name group in bundled default field sets.

= 0.1.96 =
* Match the bundled default field set to the current admin user's display language, falling back to the site language.

= 0.1.95 =
* Add a one-click, site-language-aware bundled default field set to the empty editor.

= 0.1.94 =
* Preserve the selected first, middle, or last position when sorting fields inside groups.

= 0.1.93 =
* Keep the feature-control gray background when feature fields are placed inside a Box Group.

= 0.1.92 =
* Strengthen the dedicated save action button sizing against WordPress core button styles.

= 0.1.91 =
* Give the required Add / Save User field a distinct full-width action section.

= 0.1.90 =
* Keep profile label and content columns stable when a full-width Box Group appears first.

= 0.1.89 =
* Use the Box Group as the only frame when it contains feature controls.

= 0.1.88 =
* Preserve horizontal group columns for feature controls while enclosing them in one shared outer frame.

= 0.1.87 =
* Add role-based display controls to Sessions and Application Passwords while keeping ordinary fields and groups role-neutral.

= 0.1.86 =
* Hide the native Account Management heading when all native account controls are moved into the field set or hidden in Extras.

= 0.1.85 =
* Remove the empty native Account Management heading after its controls are placed in the managed field set.

= 0.1.84 =
* Include Tools in the WordPress Tools submenu label.

= 0.1.83 =
* Ensure the save section uses the same desktop content-column alignment as grouped feature controls.

= 0.1.82 =
* Align the standalone save section with the control columns used by grouped feature fields.

= 0.1.81 =
* Display the profile picture as an unframed full-width field instead of a feature panel.

= 0.1.80 =
* Expand biographical info in horizontal groups and place functional WordPress session and application-password controls in managed fields.

= 0.1.79 =
* Match WordPress profile editing with Gravatar guidance and an expandable new-password generator.

= 0.1.78 =
* Fix horizontal field alignment, preview admin color schemes instantly, and group feature controls in one frame.

= 0.1.77 =
* Rename distribution-set wording to field-set wording throughout the Tools screen.

= 0.1.76 =
* Bundle a WordPress default profile preset and keep complex native account controls as safe fallbacks.

= 0.1.75 =
* Align the empty-state upload icon and Extras checkboxes, and complete the Japanese translations.

= 0.1.74 =
* Let an empty editor upload and validate a field-set JSON file directly.

= 0.1.73 =
* Show Start Over only after at least one field has been saved.

= 0.1.72 =
* Replace the reset wording with a clearer Start Over action that returns fields and Extra settings to their initial state.

= 0.1.71 =
* Rename the status control, align its options horizontally, and add a protected reset link.

= 0.1.70 =
* Use quiet neutral styling for Group, Box, Conditional, and Accordion editor badges.

= 0.1.69 =
* Move required badges before field titles in the editor and match their color-scheme behavior to profile screens.

= 0.1.68 =
* Export named distribution sets as JSON files and import them directly from a file.
* Keep export-code copy and paste as a recovery fallback.

= 0.1.67 =
* Add Tools > atshift User Profile Fields with versioned JSON export, validated import, and protected plugin-data deletion.

= 0.1.66 =
* Let profile textareas use the full available width instead of WordPress's fixed profile-page width.

= 0.1.65 =
* Use the dark admin color-scheme tone with white text for required badges.

= 0.1.64 =
* Place required badges before field headings.
* Use the darker admin color-scheme tone for group outlines, required badges, and conditional emphasis.

= 0.1.63 =
* Show required badges only on actual input fields, without repeating them on parent Box or Accordion Group headings.

= 0.1.62 =
* Use a neutral gray background for profile feature groups.

= 0.1.61 =
* Allow Conditional Groups to be placed inside Box Groups.
* Remove the long safety-mode explanation from the Publish panel.

= 0.1.60 =
* Added fail-open compatibility protection for managed WordPress profile fields.
* Disabling the field group now restores the native WordPress profile screen without hiding default fields.
* Unsupported managed fields automatically fall back to their native WordPress display.
* Added a wp-config.php emergency safe mode that bypasses all profile-screen integration without deleting settings.

= 0.1.0 =
* Initial basic version.
